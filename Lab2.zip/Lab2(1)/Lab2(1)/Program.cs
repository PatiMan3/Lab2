﻿using System;

namespace Lab2_1_
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 0;
            int k = 0;

            string[] array1 = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            string[] array2 = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);


            if (array1.Length < array2.Length)
            {
                k = array1.Length;
            }
            else k = array2.Length;

            for (int i = 0; i < k; ++i)
            {
                if (array1[i] == array2[i])
                {
                    ++a;
                }
            }
            for (int i = k - 1; i >= 0; --i)
            {
                if (array1[i] == array2[i])
                {
                    ++b;
                }
            }
            if (a == 0 && b == 0)
            {
                Console.WriteLine("0");
            }
            else if (a > b)
            {
                Console.WriteLine(a);
            }
            else
            {
                Console.WriteLine(b);
            }

            Console.ReadKey();
        }
    }
}
