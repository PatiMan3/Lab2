﻿using System;

namespace Lab2_8_
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] array = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            int[] numbers = new int[array.Length];

            int i = 0;

            foreach (var q in array)
            {
                numbers[i] = Convert.ToInt32(q);
                ++i;
            }

            int num = numbers[0];
            int frequent = 1;
            int bestNum = num;
            int bestfrequent = frequent;

            for (int j = 0; j < numbers.Length; ++j)
            {
                num = numbers[j]; frequent = 1;

                for (int z = 0; z < numbers.Length; ++z)
                {
                    if (numbers[z] == numbers[j])
                    {
                        frequent++;
                    }
                }

                frequent--;

                if (frequent > bestfrequent)
                {
                    bestfrequent = frequent;
                    bestNum = num;
                }

            }
            Console.WriteLine(bestNum);


            Console.ReadKey();
        }
    }
}
