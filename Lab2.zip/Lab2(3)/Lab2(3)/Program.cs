﻿using System;
using System.Security.Cryptography;

namespace Lab2_3_
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] a1 = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);


            int k = (a1.Length) / 2;
            int n = k / 2;
            int i = 0;


            int[] new_array = new int[a1.Length];
            foreach (var q in a1)
            {
                new_array[i] = Convert.ToInt32(q);
                ++i;
            }

            int l = 0;  
            int[] array1 = new int[k];
            int[] array2 = new int[k];
            int[] sum = new int[k];

            for (int j = n - 1; j >= 0; --j)
            {

                array1[l] = new_array[j];
                    ++l;

            }

            for( int j = a1.Length - 1; j >= a1.Length - n; --j)
            {

                array1[l] = new_array[j];
                ++l;

            }

            l = 0;

            Console.WriteLine();

            for(int j = n; j < a1.Length - n;++j)
            {
                array2[l] = new_array[j];
                ++l;
            }

            for(int j = 0;j<k;++j)
            {
                sum[j] = array2[j] + array1[j];
            }

            foreach(var q in sum)
            {
                Console.Write($"{q} ");
            }
            Console.ReadKey();
        }
    }
}
