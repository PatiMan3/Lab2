﻿using System;

namespace Lab2_5_
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] a1 = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            string[] a2 = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);


            char[] arr1 = new char[a1.Length];

            char[] arr2 = new char[a2.Length];

            for (int i = 0; i < a1.Length; ++i)
            {
                arr1[i] = Convert.ToChar(a1[i]);
            }

            for (int i = 0; i < a2.Length; ++i)
            {
                arr2[i] = Convert.ToChar(a2[i]);
            }

            if (arr1[0] < arr2[0])
            {
                foreach (var q in arr1)
                {
                    Console.Write($"{q}");
                }

                Console.WriteLine();

                foreach (var q in arr2)
                {
                    Console.Write($"{q}");
                }

            }
            else
            {
                
                foreach (var q in arr2)
                {
                    Console.Write($"{q}");
                }

                Console.WriteLine();

                foreach (var q in arr1)
                {
                    Console.Write($"{q}");
                }

            }

            Console.ReadKey();
        }
    }
}
