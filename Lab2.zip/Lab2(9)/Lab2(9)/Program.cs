﻿using System;

namespace Lab2_9_
{
    class Program
    {
        static void Main(string[] args)
        {
            string array = Console.ReadLine();

            char[] A = new char[array.Length];

            for (int i = 0; i < array.Length; ++i)
            {
                Console.WriteLine($"{array[i]} -> {(int)array[i] - 97}");
            }

            Console.ReadKey();
        }
    }
}
